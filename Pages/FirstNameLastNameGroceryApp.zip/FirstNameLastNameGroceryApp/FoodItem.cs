public class FoodItem
{
    public int quantityNumberProperty {get; set;}
    public string vegetables { get; set; }
    public string essentials { get; set; }
    public string drinks{get; set;}
}