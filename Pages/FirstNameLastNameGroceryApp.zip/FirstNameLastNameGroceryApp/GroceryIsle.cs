public class GroceryIsle
{
    public string ListOfFoodItem {get; set;}
    public string IsleName { get; set; }
    public int IsleNumber { get; set; }

    public string IsDone{get; set;}

    public string GroceryItem{get; set;}
   
}